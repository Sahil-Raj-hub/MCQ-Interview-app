package Practice_bot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IPBotApplication {

	public static void main(String[] args) {
		SpringApplication.run(IPBotApplication.class, args);
	}

}
