package Practice_bot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IPBotApplicationTests {

	@Test
	void contextLoads() {
	}

}
